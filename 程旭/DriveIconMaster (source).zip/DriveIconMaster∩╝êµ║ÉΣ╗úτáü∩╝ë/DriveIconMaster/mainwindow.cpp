#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QDialog>
#include <QDir>
#include <QFile>
#include <QIcon>
#include <QStorageInfo>
#include <QSettings>
#include <QWidget>
#include <QFileDialog>
#include <stdlib.h>
#include <aboutuswindow.h>
#include <aboutwindow.h>

QString icopth;

MainWindow::MainWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->btnref,SIGNAL(clicked()),this,SLOT(slot_btnref_clicked()));
    connect(ui->btnapp,SIGNAL(clicked()),this,SLOT(slot_btnapp_clicked()));
    connect(ui->cmbdrv,SIGNAL(currentTextChanged()),this,SLOT(slot_cmbdrv_currentTextChanged()));
    connect(ui->btnopn,SIGNAL(clicked()),this,SLOT(slot_btnopn_clicked()));
    connect(ui->btndef,SIGNAL(clicked()),this,SLOT(slot_btndef_clicked()));
    connect(ui->btnabt,SIGNAL(clicked()),this,SLOT(slot_btnabt_clicked()));
    connect(ui->btnabtus,SIGNAL(clicked()),this,SLOT(slot_btnabtus_clicked()));
    setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    ui->lblico->setScaledContents(1);
    ui->txtpath->clear();

    MainWindow::inicmbdrv();

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::addcmbdrv()

{
    QList<QStorageInfo> drvinfolist=QStorageInfo::mountedVolumes();
    foreach (QStorageInfo storage,drvinfolist)
    {
      if(storage.isReady())
      {

          ui->cmbdrv->addItem(storage.rootPath().mid(0,2)+"    名称："+storage.name()+"   文件系统类型："+storage.fileSystemType());

      }
    }
    ui->cmbdrv->setCurrentIndex(0);

}
void MainWindow::inicmbdrv()
{
    addcmbdrv();
    QDir d;
    if (d.exists(ui->cmbdrv->currentText().mid(0,1)+":/autorun.inf"))
    {
        QSettings ini(ui->cmbdrv->currentText().mid(0,1)+":/autorun.inf",QSettings::IniFormat);
        ini.beginGroup("Autorun");
       ui->lblico->setScaledContents(1);
       if (!ini.value("ICON").toString().isEmpty())
       {
           ui->txtpath->setText(ini.value("ICON").toString());
       }
        ini.endGroup();
    }
}

void MainWindow::setdrvico()
{
    QSettings ini(ui->cmbdrv->currentText().mid(0,2)+"/autorun.inf",QSettings::IniFormat);
    ini.beginGroup("Autorun");
    QFile d;

    if (d.exists(icopth))
    {
        QFile::remove(ui->cmbdrv->currentText().mid(0,2)+"/Driveicon.ico");
        if(d.copy(icopth,ui->cmbdrv->currentText().mid(0,2)+"/Driveicon.ico"))
        {
            ini.setValue("ICON","Driveicon.ico");

            QMessageBox msg;
            msg.setWindowTitle("成功");
           msg.setIcon(QMessageBox::Information);
           msg.setText("设置成功！重新启动计算机后立即生效!");

           msg.addButton("立即重启",QMessageBox::AcceptRole);
           msg.addButton("稍后重启",QMessageBox::RejectRole);

           if(msg.exec()==QMessageBox::AcceptRole)
           {
               system("shutdown.exe /r /t 00");
           }
        }
        else {
            QMessageBox::critical(this,"失败","设置失败！请检查磁盘是否可以写入。","确定");
        }

    }
    else {
        QMessageBox::critical(this,"失败","设置失败！请检查指定图标是否存在。","确定");
    }
}



//槽函数定义处：
void MainWindow::slot_cmbdrv_currentTextChanged()

{
    ui->txtpath->setText("");
    icopth="";
    QDir d;
    if (d.exists(ui->cmbdrv->currentText().mid(0,1)+":/autorun.inf"))
    {
        QSettings ini(ui->cmbdrv->currentText().mid(0,1)+":/autorun.inf",QSettings::IniFormat);
        ini.beginGroup("Autorun");
       ui->lblico->setScaledContents(1);
       if (!ini.value("ICON").toString().isEmpty())
       {
           ui->txtpath->setText(ini.value("ICON").toString());
       }
        ini.endGroup();
    }



}

void MainWindow::slot_btnapp_clicked()
{
    if(icopth!="")
    {
        setdrvico();
    }
    else {

        QMessageBox::critical(this,"失败","请先选择文件。","确定");
    }
}

void MainWindow::slot_btnref_clicked()
{
    ui->cmbdrv->clear();
    ui->txtpath->clear();
    inicmbdrv();


}

void MainWindow::slot_btndef_clicked()
{
    if(QFile::remove(ui->cmbdrv->currentText().mid(0,1)+":/autorun.inf"))
    {
        QFile::remove(ui->cmbdrv->currentText().mid(0,1)+":/Driveicon.ico");
        slot_btnref_clicked();
        QMessageBox msg;
        msg.setWindowTitle("成功");
       msg.setIcon(QMessageBox::Information);
       msg.setText("设置成功！重新启动计算机后立即生效!");

       msg.addButton("立即重启",QMessageBox::AcceptRole);
       msg.addButton("稍后重启",QMessageBox::RejectRole);

       if(msg.exec()==QMessageBox::AcceptRole)
       {
           system("shutdown.exe /r /t 00");
       }

    }
    else {
        QMessageBox::critical(this,"失败","恢复失败。","确定");
    }
}

void MainWindow::slot_btnopn_clicked()
{
    icopth=QDir::cleanPath(QFileDialog::getOpenFileName(this,"选择一个图标文件",QDir::currentPath(),"图标文件(*.ico)"));
    if(!icopth.isEmpty())
    {
        ui->txtpath->setText(icopth);
    }

}

void MainWindow::slot_btnabt_clicked()
{
    AboutWindow *abtwnd=new AboutWindow();
    abtwnd->setVisible(1);
    abtwnd->show();
}

void MainWindow::slot_btnabtus_clicked()
{
    AboutUsWindow *abtwndus=new AboutUsWindow();
    abtwndus->setVisible(1);
    abtwndus->show();
}


void MainWindow::on_cmbdrv_currentTextChanged(const QString &arg1)
{
    ui->txtpath->setText("");

    icopth="";
    QDir d;
    if (d.exists(ui->cmbdrv->currentText().mid(0,1)+":/autorun.inf"))
    {
        QSettings ini(ui->cmbdrv->currentText().mid(0,1)+":/autorun.inf",QSettings::IniFormat);
        ini.beginGroup("Autorun");
       ui->lblico->setScaledContents(1);
       if (!ini.value("ICON").toString().isEmpty())
       {
           ui->txtpath->setText(ini.value("ICON").toString());
       }
        ini.endGroup();
    }
}


