#include <iostream>
using name space std;
int main()
{
	int array [6];
	cout<<"Please name the six items in this array one by one."<<endl;
	int i; 
	for (i=0;i<6;i++)
	{
		cout<<"array["<< i <<"]";
		cin>>array[i];
		cout <<endl;
		cout<<"Sucess.Here is the value of each items."<<endl;
	}
	for (i=0;i<6;i++)
	{
		cout<<"array["<<i<<"]="<<array[i]<<endl;
	}
	cout<<"Press 0 and Enter,and the program will make these items turns from small to big of the values.Or Press 1 and Enter,and it will make them turns from big to small."<<endl;
	int choice;
	int j;
	int t;
	label:
	cin>>choice;
	cout<<end;
	switch (choice)
	{
		case 0:
		{
			for (i=0;i<5;i++)
			{
				for (j=i+1;j<6;j++)
				{
					if (array[i]>array[j])
					{
						t=array[j];
						array[j]=array[i];
						array[i]=t;
					}
				}
			}
		break;
		}
		case 1:
		{
			for (i=0;i<5;i++)
			{
				for (j=i+1;j<6;j++)
				{
					if (array[i]<array[j])
					{
						t=array[j];
						array[j]=array[i];
						array[i]=t;
					}
				}
			}
			break;
		}
		default:
		{
			cout <<"Your input is illegal.Please input it again."
			goto label;
			break
		case 